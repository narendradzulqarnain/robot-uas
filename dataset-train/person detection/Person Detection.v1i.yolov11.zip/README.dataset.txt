# Person Detection > 2025-06-11 4:53pm
https://universe.roboflow.com/uas-robotika/person-detection-aclqb

Provided by a Roboflow user
License: CC BY 4.0

