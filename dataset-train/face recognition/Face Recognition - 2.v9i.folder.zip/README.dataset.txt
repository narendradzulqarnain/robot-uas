# Face Recognition - 2 > 2025-06-12 7:30pm
https://universe.roboflow.com/uas-robotika/face-recognition-2-atjqz

Provided by a Roboflow user
License: CC BY 4.0

