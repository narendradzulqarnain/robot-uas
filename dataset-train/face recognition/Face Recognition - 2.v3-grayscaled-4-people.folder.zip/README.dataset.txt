# Face Recognition - 2 > Grayscaled - 4 People
https://universe.roboflow.com/uas-robotika/face-recognition-2-atjqz

Provided by a Roboflow user
License: CC BY 4.0

