# Face Recognition > 2025-06-12 2:27am
https://universe.roboflow.com/uas-robotika/face-recognition-usxq7

Provided by a Roboflow user
License: CC BY 4.0

