# Face Recognition > 2025-06-11 7:56pm
https://universe.roboflow.com/uas-robotika/face-recognition-usxq7

Provided by a Roboflow user
License: CC BY 4.0

